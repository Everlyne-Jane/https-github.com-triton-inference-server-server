#!/bin/bash
# Copyright (c) 2022, NVIDIA CORPORATION & AFFILIATES. All rights reserved.

export TRITON_SERVER_CPU_ONLY=1
